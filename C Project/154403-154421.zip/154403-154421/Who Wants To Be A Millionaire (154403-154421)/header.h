///A project by Junaid Mahmud (154403) and Nazmus Sakib (154421)
#include<bits/stdc++.h>

using namespace std;

void delay(double sec);
void border1();
void border();
void over();
void instruction();
